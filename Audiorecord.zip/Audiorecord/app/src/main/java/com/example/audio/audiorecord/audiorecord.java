
package com.example.audio.audiorecord;
//package com.android.audiorecordtest;

//Importamos varias funciones y widgets
//entre estas las mas importantes son mediaplayer y mediarecorder
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

import android.app.Activity;
import android.widget.LinearLayout;
import android.os.Bundle;
import android.os.Environment;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.View;
import android.view.View.OnClickListener;
import android.content.Context;
import android.util.Log;
import android.media.MediaRecorder;
import android.media.MediaPlayer;

import java.io.IOException;

public class audiorecord extends Activity
//public class audiorecord extends AppCompatActivity
{

    private static final String LOG_TAG = "Grabadora";
    private static String mFileName = null;
//Creamos las funciones para el boton que usaremos para grabar, junto con el uso de media recorder
    private RecordButton mRecordButton = null;
    private MediaRecorder mRecorder = null;
    //De la misma forma con el boton que usaremos para reproducir, junto con el uso de media player
    private PlayButton   mPlayButton = null;
    private MediaPlayer   mPlayer = null;

    //En Onrecord se evalua dependiendo de, si el usuario va a empezar a grabar o parar a grabar
    private void onRecord(boolean start) {
        if (start) {
            startRecording();
        } else {
            stopRecording();
        }
    }
    //En Onplay se evalua dependiendo de, si el usuario va a empezar a reproducir o parar de reproducir
    private void onPlay(boolean start) {
        if (start) {
            startPlaying();
        } else {
            stopPlaying();
        }
    }
//En estar nplaying se evalua primero si hay un archivo el cual reproducir, de lo cotrario mandara un error, esto por medio dle try y catch
    private void startPlaying() {
        mPlayer = new MediaPlayer();
        try {
            mPlayer.setDataSource(mFileName);
            mPlayer.prepare();
            mPlayer.start();
        } catch (IOException e) {
            Log.e(LOG_TAG, "prepare() failed");
        }
    }
    //aqui se para de reproducir
    private void stopPlaying() {
        mPlayer.release();
        mPlayer = null;
    }
//En la funcion StarRecording se activa el microfono y se coloca un nombre por defecto al archivo que se va a grabar
    private void startRecording() {
        mRecorder = new MediaRecorder();
        mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mRecorder.setOutputFile(mFileName);
        mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);

        try {
            mRecorder.prepare();
        } catch (IOException e) {
            Log.e(LOG_TAG, "prepare() failed");
        }

        mRecorder.start();
    }
    //aqui se para de grabar
    private void stopRecording() {
        mRecorder.stop();
        mRecorder.release();
        mRecorder = null;
    }
//Clase del boton junton a la extencion del boton
    class RecordButton extends Button {
        boolean mStartRecording = true;

        OnClickListener clicker = new OnClickListener() {
            public void onClick(View v) {
                onRecord(mStartRecording);
                if (mStartRecording) {
                    setText("grabacion parada");
                } else {
                    setText("grabando");
                }
                mStartRecording = !mStartRecording;
            }
        };

        public RecordButton(Context ctx) {
            super(ctx);
            setText("grabando");
            setOnClickListener(clicker);
        }
    }
    //Clase del boton para reproducir junton a la extencion del boton
    class PlayButton extends Button {
        boolean mStartPlaying = true;

        OnClickListener clicker = new OnClickListener() {
            public void onClick(View v) {
                onPlay(mStartPlaying);
                if (mStartPlaying) {
                    setText("reproduccion detenida");
                } else {
                    setText("reproduciendo");
                }
                mStartPlaying = !mStartPlaying;
            }
        };

        public PlayButton(Context ctx) {
            super(ctx);
            setText("reproduciendo");
            setOnClickListener(clicker);
        }
    }
//Se le coloca un nombre al archivo grabado
    public audiorecord() {
        mFileName = Environment.getExternalStorageDirectory().getAbsolutePath();
        mFileName += "/audiorecordtest.3gp";
    }

    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);

        LinearLayout ll = new LinearLayout(this);
        mRecordButton = new RecordButton(this);
        ll.addView(mRecordButton,
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        0));
        mPlayButton = new PlayButton(this);
        ll.addView(mPlayButton,
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        0));
        setContentView(ll);
    }

    @Override
    public void onPause() {
        super.onPause();
        if (mRecorder != null) {
            mRecorder.release();
            mRecorder = null;
        }

        if (mPlayer != null) {
            mPlayer.release();
            mPlayer = null;
        }
    }
}









